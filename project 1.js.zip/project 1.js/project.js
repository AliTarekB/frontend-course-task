/* const newDiv = document.createElement("div");
const newSpan = document.createElement("span");
const newtext = document.createElement("product title 1");
const TextSpan = document.createElement("product description 1");

newDiv.appendChild(newtext);
newDiv.appendChild(newSpan);
newSpan.appendChild(TextSpan);
document.getElementsByClassName("create").onclick
newDiv.style.border = "solid";
newDiv.style.borderRadius ="8px";
newDiv.style.backgroundColor = "blue";
 */
const search = () =>{
   let input = document.querySelector("#search").value
   input = input.toLowerCase();
   let X = document.getElementsByTagName("h2")

for(let i=0; i<X.length ;i++){
   if(!X[i].innerHTML.toLowerCase().includes(input)){
      X[i].style.display="none";
   }



}

}
  function display(){
  document.getElementById("submit").style.display='block'
  document.getElementById("create").style.display='none'
  document.getElementById("task").style.display='block'
  document.getElementById("desc").style.display='block'

}
let title;
let desc;
 function submit(){
  document.getElementById("edit").style.display='block'
  document.getElementById("submit").style.display='none'
  document.getElementById("delete").style.display='none'
  title = document.getElementById("task").value;
  document.getElementById("title").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc").value;
  document.getElementById("description").innerHTML ='Description:'+ desc

  document.getElementById("task").style.display='none'
  document.getElementById("desc").style.display='none'

}
 function edit(){
  document.getElementById("submit").style.display='block'
  document.getElementById("delete").style.display='block'
  document.getElementById("edit").style.display='none'
  document.getElementById("task").style.display='block'
  document.getElementById("desc").style.display='block'


}
function restart(){
   document.getElementById("create").style.display='block'
   document.getElementById("submit").style.display='none'
   document.getElementById("delete").style.display='none'
   document.getElementById("task").style.display='none'
   document.getElementById("desc").style.display='none'
   document.getElementById("title").innerHTML ='task deleted'
   document.getElementById("description").innerHTML ='task deleted'


}
 function display2(){
  document.getElementById("submit2").style.display='block'
  document.getElementById("create2").style.display='none'
  document.getElementById("task2").style.display='block'
  document.getElementById("desc2").style.display='block'

}

 function submit2(){
  document.getElementById("edit2").style.display='block'
  document.getElementById("submit2").style.display='none'
  document.getElementById("delete2").style.display='none'
  title = document.getElementById("task2").value;
  document.getElementById("title2").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc2").value;
  document.getElementById("description2").innerHTML ='Description:'+ desc
  document.getElementById("task2").style.display='none'
  document.getElementById("desc2").style.display='none'

}
 function edit2(){
  document.getElementById("submit2").style.display='block'
  document.getElementById("delete2").style.display='block'
  document.getElementById("edit2").style.display='none'
  document.getElementById("task2").style.display='block'
  document.getElementById("desc2").style.display='block'


}
function restart2(){
   document.getElementById("create2").style.display='block'
   document.getElementById("submit2").style.display='none'
   document.getElementById("delete2").style.display='none'
   document.getElementById("task2").style.display='none'
   document.getElementById("desc2").style.display='none'
   document.getElementById("title2").innerHTML ='task deleted'
   document.getElementById("description2").innerHTML ='task deleted'

}

function display3(){
  document.getElementById("submit3").style.display='block'
  document.getElementById("create3").style.display='none'
  document.getElementById("task3").style.display='block'
  document.getElementById("desc3").style.display='block'

}

 function submit3(){
  document.getElementById("edit3").style.display='block'
  document.getElementById("submit3").style.display='none'
  document.getElementById("delete3").style.display='none'
  title = document.getElementById("task3").value;
  document.getElementById("title3").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc3").value;
  document.getElementById("description3").innerHTML ='Description:'+ desc
  document.getElementById("task3").style.display='none'
  document.getElementById("desc3").style.display='none'

}
 function edit3(){
  document.getElementById("submit3").style.display='block'
  document.getElementById("delete3").style.display='block'
  document.getElementById("edit3").style.display='none'
  document.getElementById("task3").style.display='block'
  document.getElementById("desc3").style.display='block'


}
function restart3(){
   document.getElementById("create3").style.display='block'
   document.getElementById("submit3").style.display='none'
   document.getElementById("delete3").style.display='none'
   document.getElementById("task3").style.display='none'
   document.getElementById("desc3").style.display='none'
   document.getElementById("title3").innerHTML ='task deleted'
   document.getElementById("description3").innerHTML ='task deleted'

}

  function display4(){
  document.getElementById("submit4").style.display='block'
  document.getElementById("create4").style.display='none'
  document.getElementById("task4").style.display='block'
  document.getElementById("desc4").style.display='block'

}

 function submit4(){
  document.getElementById("edit4").style.display='block'
  document.getElementById("submit4").style.display='none'
  document.getElementById("delete4").style.display='none'
  title = document.getElementById("task4").value;
  document.getElementById("title4").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc4").value;
  document.getElementById("description4").innerHTML ='Description:'+ desc

  document.getElementById("task4").style.display='none'
  document.getElementById("desc4").style.display='none'

}
 function edit4(){
  document.getElementById("submit4").style.display='block'
  document.getElementById("delete4").style.display='block'
  document.getElementById("edit4").style.display='none'
  document.getElementById("task4").style.display='block'
  document.getElementById("desc4").style.display='block'


}
function restart4(){
   document.getElementById("create4").style.display='block'
   document.getElementById("submit4").style.display='none'
   document.getElementById("delete4").style.display='none'
   document.getElementById("task4").style.display='none'
   document.getElementById("desc4").style.display='none'
   document.getElementById("title4").innerHTML ='task deleted'
   document.getElementById("description4").innerHTML ='task deleted'


}
 function display5(){
  document.getElementById("submit5").style.display='block'
  document.getElementById("create5").style.display='none'
  document.getElementById("task5").style.display='block'
  document.getElementById("desc5").style.display='block'

}

 function submit5(){
  document.getElementById("edit5").style.display='block'
  document.getElementById("submit5").style.display='none'
  document.getElementById("delete5").style.display='none'
  title = document.getElementById("task5").value;
  document.getElementById("title5").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc5").value;
  document.getElementById("description5").innerHTML ='Description:'+ desc
  document.getElementById("task5").style.display='none'
  document.getElementById("desc5").style.display='none'

}
 function edit5(){
  document.getElementById("submit5").style.display='block'
  document.getElementById("delete5").style.display='block'
  document.getElementById("edit5").style.display='none'
  document.getElementById("task5").style.display='block'
  document.getElementById("desc5").style.display='block'


}
function restart5(){
   document.getElementById("create5").style.display='block'
   document.getElementById("submit5").style.display='none'
   document.getElementById("delete5").style.display='none'
   document.getElementById("task5").style.display='none'
   document.getElementById("desc5").style.display='none'
   document.getElementById("title5").innerHTML ='task deleted'
   document.getElementById("description5").innerHTML ='task deleted'

}

function display6(){
  document.getElementById("submit6").style.display='block'
  document.getElementById("create6").style.display='none'
  document.getElementById("task6").style.display='block'
  document.getElementById("desc6").style.display='block'

}

 function submit6(){
  document.getElementById("edit6").style.display='block'
  document.getElementById("submit6").style.display='none'
  document.getElementById("delete6").style.display='none'
  title = document.getElementById("task6").value;
  document.getElementById("title6").innerHTML ='Title:'+ title 
  desc = document.getElementById("desc6").value;
  document.getElementById("description6").innerHTML ='Description:'+ desc
  document.getElementById("task6").style.display='none'
  document.getElementById("desc6").style.display='none'

}
 function edit6(){
  document.getElementById("submit6").style.display='block'
  document.getElementById("delete6").style.display='block'
  document.getElementById("edit6").style.display='none'
  document.getElementById("task6").style.display='block'
  document.getElementById("desc6").style.display='block'


}
function restart6(){
   document.getElementById("create6").style.display='block'
   document.getElementById("submit6").style.display='none'
   document.getElementById("delete6").style.display='none'
   document.getElementById("task6").style.display='none'
   document.getElementById("desc6").style.display='none'
   document.getElementById("title6").innerHTML ='task deleted'
   document.getElementById("description6").innerHTML ='task deleted'

}
